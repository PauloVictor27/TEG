#include <stdio.h>
#include <stdlib.h>

//Struct para armazenar os valores de distancia e tempo de cada rua
typedef struct{
	int distancia;
	int tempo;
}Rua;
